Documentation client

1. Remplir le formulaire dans index.html.
2. Recevoir les coordonnées de paiement par email.
3. Effectuer le virement et envoyer la preuve de paiement.
4. Recevoir un code de confirmation unique.
5. Suivre la progression de l'investissement sur suivi.html.
